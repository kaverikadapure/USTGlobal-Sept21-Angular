import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {
 carData : any[]= [];

  cars = [
    {
      brand : "Bugatti Chiron Sport: 261 MPH",
      img : "https://the-drive.imgix.net/https%3A%2F%2Fs3.amazonaws.com%2Fthe-drive-staging%2Fmessage-editor%252F1533180655719-se-image-033ebf76582a0b3705ec55100ee96359.jpg?auto=compress%2Cformat&ixlib=js-1.4.1&s=7316b88ab2f376299d42130aa8ac8960",
      details : "The Chiron Sport's top speed of 261 miles per hour quite literally overwhelms every machine listed here, and that's exactly what Bugatti set off to accomplish with its ferocious yet luxurious land missile. The Chiron Sport is powered by the same 1,479-horsepower [ED. NOTE: Whenever I read that stat, I lol], 8.0-liter quad-turbocharged W-16 engine as the regular Chiron, but it weighs 40 pounds less and is therefore just a tad faster. "
    },
    {
      brand : "Mercedes-AMG Project One: At Least 217 MPH",
      img : "https://the-drive.imgix.net/https%3A%2F%2Fs3.amazonaws.com%2Fthe-drive-staging%2Fmessage-editor%252F1533180573845-17c698_012-source.jpg?auto=compress%2Cformat&ixlib=js-1.4.1&s=84cbc41644a37f785b26f1d0c75c6019",
      details : "It's not common for an automaker to release estimated performance figures, but in the case of Mercedes-AMG, they've simply stated that its new hypercar, the Project One, can reach a maximum speed of at least 217 miles per hour. Could it reach 220, 225 or maybe even 230? Given the Formula 1-derived hybrid power unit it's not completely far-fetched, but that'd simply be speculation."
    },
    {
      brand : "Lamborghini Aventador SVJ: 217 MPH",
      img : "https://the-drive-3.imgix.net/https%3A%2F%2Fs3.amazonaws.com%2Fthe-drive-staging%2Fmessage-editor%252F1533255555989-516344.jpg?auto=compress%2Cformat&ixlib=js-1.4.1&s=d91b9577bf5cccc1e6c141268b903073",
      details : "The new Lamborghini Aventador SVJ adopts the Italian automaker's famous Jota moniker, which adds another layer of hardcore-ness to the already racy SV trim by calling on the spirit of the powerful Miura P400 Jota from the '70s, which was designed to meet the FIA's  class rulebook. "
    },
    {
      brand : " Ford GT: 216 MPH",
      img : "https://the-drive.imgix.net/https%3A%2F%2Fs3.amazonaws.com%2Fthe-drive-staging%2Fmessage-editor%252F1533180541072-wdmp_170425_14289.jpg?auto=compress%2Cformat&ixlib=js-1.4.1&s=3b912ccc07090cf3ae30e22a9c669845",
      details : "Unlike the two other Americans on this list, the Ford GT didn't get the Blue Collar memo. As a result, this low-to-the-ground supercar starts at an eye-watering $450,000, but its 216-mph top speed and dazzling eye candy profile almost justify the hefty price. "
    },
    {
      brand : "Chevrolet Corvette ZR1: 212 MPH",
      img : "https://the-drive-2.imgix.net/https%3A%2F%2Fs3.amazonaws.com%2Fthe-drive-staging%2Fmessage-editor%252F1533180347753-2019-chevrolet-corvette-zr1-012.jpg?auto=compress%2Cformat&ixlib=js-1.4.1&s=6678e373e54eefc0db3259eb002fd132",
      details : "The 212-mph Chevrolet Corvette ZR1 continues the American tradition of building world-class performers at just a fraction of the cost of the Europeans. The Dodge Challenger SRT Hellcat Redeye is built on a base model that starts at just $30,000; similarly, the entry-level variant of the $121,000 Chevy Corvette ZR1 Coupe starts less than $60,000. "
    }
    
  ]
  constructor() { }

  show(car){
    this.carData=car;

  }

  ngOnInit() {
  }

}
