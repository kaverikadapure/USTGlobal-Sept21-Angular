import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddTaskComponent } from './add-task/add-task.component';
import { ViewTaskComponent } from './view-task/view-task.component';



const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([
    { path: 'addtask', component:AddTaskComponent},
    { path:'view', component: ViewTaskComponent}
  ])],
  exports: [RouterModule]
})
export class AppRoutingModule { }
