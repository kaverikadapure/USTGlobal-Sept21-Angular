import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  users : any[]= [];

  constructor(private http : HttpClient) { }

  show(form : NgForm){
    
  }

  ngOnInit() {
  }

}
